import aiogram
from aiogram import Bot, types
from aiogram.dispatcher import Dispatcher, FSMContext
from aiogram.utils import executor
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.dispatcher.filters.state import State, StatesGroup
from aiogram.types import ReplyKeyboardRemove, ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton
import config

bot = Bot(token=config.token)
dp = Dispatcher(bot, storage=MemoryStorage())

@dp.message_handler(commands=["start"])
async def start(message: types.Message):
    keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(KeyboardButton('Информация'))
    keyboard.add(KeyboardButton('Ссылки'))
    keyboard.add(KeyboardButton('Заявки'))
    await bot.send_message(message.from_user.id, "Стартовое сообщение", reply_markup = keyboard)

if __name__ == '__main__':
    from handlers import dp
    
    executor.start_polling(dp, skip_updates=True,)
