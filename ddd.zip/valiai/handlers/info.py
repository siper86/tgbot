from aiogram import types
from main import dp

@dp.message_handler(text="Информация")
async def info(message: types.Message):
    await message.answer('Информация тут')
