from aiogram import types
from main import dp, Bot
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.dispatcher.filters.state import State, StatesGroup
import config
bot = Bot(token=config.token)

class States(StatesGroup):
    fill = State()

@dp.message_handler(text="Подать заявку на администрацию")
async def info(message: types.Message):
    await bot.send_message(message.from_user.id, "Введи текст заявки:")
    await States.fill.set()

@dp.message_handler(state=States.fill)
async def admin_mail(message: types.Message):
    data = message.text
    await bot.send_message(config.admin_id, data)
    await bot.send_message(message.from_user.id, "Готово")
