from aiogram import types
from main import dp
from aiogram.types import ReplyKeyboardRemove, ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton

@dp.message_handler(text="Заявки")
async def info(message: types.Message):
    keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(KeyboardButton('Подать заявку на администрацию'))
    keyboard.add(KeyboardButton('Подать заявку на сервер'))
    keyboard.add(KeyboardButton('/start'))
    await message.answer('Меню заявок', reply_markup = keyboard)
