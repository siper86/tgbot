from aiogram import types
from main import dp

@dp.message_handler(text="Подать заявку на сервер")
async def info(message: types.Message):
    await message.answer("Ссылка")

