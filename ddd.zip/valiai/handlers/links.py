from aiogram import types
from main import dp

@dp.message_handler(text="Ссылки")
async def info(message: types.Message):
    await message.answer('Тут ссылка')
